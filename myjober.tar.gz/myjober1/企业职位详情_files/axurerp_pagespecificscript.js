﻿for(var i = 0; i < 65; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u53'] = 'center';
u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('发布职位.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u43'] = 'center';
u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业中心.html');

}
});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u4'] = 'top';