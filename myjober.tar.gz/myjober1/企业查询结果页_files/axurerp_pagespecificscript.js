﻿for(var i = 0; i < 21; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u7'] = 'top';