﻿for(var i = 0; i < 70; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册页.html');

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u46'] = 'center';
u68.style.cursor = 'pointer';
$axure.eventManager.click('u68', function(e) {

if (true) {

	SetPanelVisibility('u59','hidden','none',500);

}
});
gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u23'] = 'center';u53.tabIndex = 0;

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('reg.html');

}
});
gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u7'] = 'center';
u67.style.cursor = 'pointer';
$axure.eventManager.click('u67', function(e) {

if (true) {

	SetPanelVisibility('u59','hidden','none',500);

}
});
gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u15'] = 'center';document.getElementById('u45_img').tabIndex = 0;

u45.style.cursor = 'pointer';
$axure.eventManager.click('u45', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('先逛逛.html');

}
});
u36.tabIndex = 0;

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	SetPanelVisibility('u32','hidden','none',500);

}
});
gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u50'] = 'center';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('先逛逛.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u61'] = 'center';
u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href='#';

}
});
gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u63'] = 'center';
u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('个人中心.html');

}
});
gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u44'] = 'center';u29.tabIndex = 0;

u29.style.cursor = 'pointer';
$axure.eventManager.click('u29', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('forget_pw.html');

}
});
gv_vAlignTable['u29'] = 'top';