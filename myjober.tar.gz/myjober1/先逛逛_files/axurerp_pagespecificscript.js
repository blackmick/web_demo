﻿for(var i = 0; i < 21; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u4'] = 'center';document.getElementById('u0_img').tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href='#';

}
});
gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u9'] = 'top';
u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('职场精英home.html');

}
});
gv_vAlignTable['u20'] = 'top';
u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('在校生home.html');

}
});
gv_vAlignTable['u6'] = 'center';