﻿for(var i = 0; i < 146; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u122'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u128'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u138'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u110'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u62'] = 'top';document.getElementById('u21_img').tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('人选简历.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u72'] = 'top';document.getElementById('u99_img').tabIndex = 0;

u99.style.cursor = 'pointer';
$axure.eventManager.click('u99', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('邀请页.html'), "");

}
});
gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u10'] = 'top';
u144.style.cursor = 'pointer';
$axure.eventManager.click('u144', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业中心.html');

}
});
gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u143'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u142'] = 'top';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u116'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u140'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u141'] = 'top';gv_vAlignTable['u132'] = 'top';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u66'] = 'top';
u145.style.cursor = 'pointer';
$axure.eventManager.click('u145', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('搜索人选.html');

}
});
gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u120'] = 'top';gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u114'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u126'] = 'top';