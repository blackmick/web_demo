﻿for(var i = 0; i < 35; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u30'] = 'center';
u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('__index.html');

}
});

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	SetPanelVisibility('u28','','none',500);

}
});
gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u34'] = 'center';