﻿for(var i = 0; i < 36; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u17'] = 'center';u28.tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('forget_pw.html');

}
});
gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u25'] = 'center';
u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业中心.html');

}
});
gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u5'] = 'center';u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业注册页.html');

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u34'] = 'top';