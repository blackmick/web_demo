﻿for(var i = 0; i < 60; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u55'] = 'top';