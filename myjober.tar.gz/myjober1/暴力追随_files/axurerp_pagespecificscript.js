﻿for(var i = 0; i < 113; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
document.getElementById('u21_img').tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('职位详情.html');

}
});
gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u111'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u3'] = 'top';
u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('个人中心.html');

}
});
gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u107'] = 'center';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u74'] = 'top';