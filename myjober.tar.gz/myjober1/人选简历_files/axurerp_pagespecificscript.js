﻿for(var i = 0; i < 29; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u18'] = 'center';
u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('邮件页.html'), "");

}
});

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('邀请页.html'), "");

}
});
gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u21'] = 'top';