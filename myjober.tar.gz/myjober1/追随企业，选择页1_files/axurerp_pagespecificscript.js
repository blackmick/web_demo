﻿for(var i = 0; i < 60; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u29'] = 'top';
u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('职场精英home.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u38'] = 'top';
u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业查询结果页_1.html');

}
});
gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u19'] = 'top';u36.tabIndex = 0;

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('职位列表.html');

}
});
gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u55'] = 'top';
u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业查询结果页_1.html');

}
});
