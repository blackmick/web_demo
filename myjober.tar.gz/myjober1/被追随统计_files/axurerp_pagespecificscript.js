﻿for(var i = 0; i < 20; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u11'] = 'top';
u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业中心.html');

}
});
gv_vAlignTable['u7'] = 'top';