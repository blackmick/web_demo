﻿for(var i = 0; i < 23; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});

u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('追随企业，选择页1.html');

}
});
gv_vAlignTable['u13'] = 'center';
u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('追随行业，选择页.html');

}
});

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href='#';

	self.location.href=$axure.globalVariableProvider.getLinkUrl('个人中心.html');

}
});
gv_vAlignTable['u10'] = 'top';
u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('暴力追随.html');

}
});
gv_vAlignTable['u22'] = 'center';
u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('追随职业，选择页.html');

}
});
gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u9'] = 'center';
u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('追随技术或证书，选择页.html');

}
});

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('在校生home.html');

}
});
gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u18'] = 'top';
u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('追随政策，选择页.html');

}
});
