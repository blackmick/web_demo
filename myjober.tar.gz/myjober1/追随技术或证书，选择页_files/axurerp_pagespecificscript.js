﻿for(var i = 0; i < 124; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u25'] = 'top';
u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('职场精英home.html');

}
});
gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u121'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u122'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u120'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u50'] = 'top';u123.tabIndex = 0;

u123.style.cursor = 'pointer';
$axure.eventManager.click('u123', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('职位列表.html');

}
});
gv_vAlignTable['u123'] = 'top';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u114'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u116'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u110'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u91'] = 'top';