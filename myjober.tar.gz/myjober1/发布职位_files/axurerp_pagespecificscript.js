﻿for(var i = 0; i < 53; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u21'] = 'top';
u52.style.cursor = 'pointer';
$axure.eventManager.click('u52', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('职位管理.html');

}
});
gv_vAlignTable['u34'] = 'top';
u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业中心.html');

}
});
