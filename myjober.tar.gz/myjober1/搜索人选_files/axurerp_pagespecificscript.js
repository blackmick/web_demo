﻿for(var i = 0; i < 37; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u17'] = 'top';
u29.style.cursor = 'pointer';
$axure.eventManager.click('u29', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业中心.html');

}
});

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('人选列表.html');

}
});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u21'] = 'top';