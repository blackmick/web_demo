﻿for(var i = 0; i < 36; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u30'] = 'top';document.getElementById('u32_img').tabIndex = 0;

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('更新简历.html');

}
});
gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u31'] = 'top';document.getElementById('u34_img').tabIndex = 0;

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('更新简历.html');

}
});
