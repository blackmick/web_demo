﻿for(var i = 0; i < 25; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u10'] = 'top';
u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('行业查询结果页.html');

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u2'] = 'center';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('职位列表.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u23'] = 'top';
u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('职场精英home.html');

}
});
gv_vAlignTable['u7'] = 'center';